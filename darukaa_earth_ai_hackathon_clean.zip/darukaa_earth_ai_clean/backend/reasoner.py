from .parser import parse_environment

def build_recommendation(text, retrieved):
    m = parse_environment(text)
    actions, impacted, reasoning = [], [], []

    if m.get("soc_percent") is not None and m["soc_percent"] < 1:
        actions.append("Increase organic inputs and maintain crop residue or ground cover; evaluate locally suitable diversified cropping.")
        impacted += ["soil organic carbon", "soil moisture"]
        reasoning.append("The reported SOC is low, so organic-input and cover practices are relevant.")
    if m.get("soil_moisture_percent") is not None and m["soil_moisture_percent"] < 20:
        actions.append("Prioritize residue retention, mulch and other locally appropriate water-conservation practices.")
        impacted += ["soil moisture", "water availability"]
        reasoning.append("The reported soil moisture indicates a water-availability constraint.")
    if m.get("land_use") == "monoculture":
        actions.append("Evaluate intercropping, rotation or locally appropriate agroforestry to increase crop and habitat diversity.")
        impacted += ["biodiversity", "habitat heterogeneity", "soil health"]
        reasoning.append("A monoculture has fewer crop types and structural habitat elements than a diversified system.")
    if m.get("rainfall_mm") is not None and m["rainfall_mm"] < 600:
        actions.append("Use locally adapted, water-efficient crops and align planting and irrigation with rainfall seasonality.")
        impacted += ["water availability", "crop resilience"]
        reasoning.append("The reported annual rainfall suggests water availability should be treated as a constraint; seasonality also matters.")
    if m.get("species_richness") is not None and m["species_richness"] < 10:
        actions.append("Retain or restore native vegetation patches and field margins where feasible.")
        impacted += ["species richness", "habitat quality"]
        reasoning.append("The reported richness is low, although sampling effort and area must be considered.")
    if m.get("pollution"):
        actions.append("Measure the suspected pollutant and identify its source before selecting remediation.")
        impacted += ["soil/water quality", "biodiversity"]
    if m.get("deforestation"):
        actions.append("Prioritize habitat protection, restoration and connectivity around remaining native vegetation.")
        impacted += ["habitat connectivity", "biodiversity"]
    if not actions:
        actions.append("Collect baseline soil, climate, land-use and biodiversity measurements before selecting a site-specific intervention.")
        reasoning.append("The description lacks enough quantitative information for a specific intervention.")

    evidence = [{"source": d["title"], "retrieval_score": round(d["score"],3)} for d in retrieved]
    return {
        "recommendation": " ".join(actions),
        "impacted_metrics": list(dict.fromkeys(impacted)) or ["site-specific environmental metrics"],
        "time_horizon": "0-3 months for management changes and baseline monitoring; 1-3+ years for soil-carbon and longer-term biodiversity trends.",
        "confidence": "Medium-High" if len(actions) >= 3 and retrieved else "Medium",
        "reasoning": reasoning,
        "evidence": evidence,
        "extracted_metrics": m,
    }
