from pydantic import BaseModel, Field

class EnvironmentInput(BaseModel):
    text: str = Field(min_length=1)

class ChatInput(BaseModel):
    session_id: str = Field(min_length=1)
    text: str = Field(min_length=1)
