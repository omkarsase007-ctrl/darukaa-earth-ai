from pathlib import Path
from fastapi import FastAPI
from .models import EnvironmentInput, ChatInput
from .rag import LocalRAG
from .reasoner import build_recommendation
from .conversation import add, context

BASE = Path(__file__).resolve().parent.parent
rag = LocalRAG(BASE / "knowledge")
app = FastAPI(title="Darukaa.Earth AI Biodiversity Reasoning API")

@app.get("/")
def root():
    return {"message":"Darukaa.Earth AI is running","docs":"/docs"}

@app.get("/health")
def health():
    return {"status":"ok","knowledge_documents":len(rag.documents)}

def answer(text):
    return build_recommendation(text, rag.search(text))

@app.post("/recommend")
def recommend(payload: EnvironmentInput):
    return answer(payload.text)

@app.post("/chat")
def chat(payload: ChatInput):
    previous = context(payload.session_id)
    combined = "\n".join(x["text"] for x in previous[-4:]) + "\n" + payload.text
    result = answer(combined)
    add(payload.session_id, "user", payload.text)
    add(payload.session_id, "assistant", result["recommendation"])
    return result
