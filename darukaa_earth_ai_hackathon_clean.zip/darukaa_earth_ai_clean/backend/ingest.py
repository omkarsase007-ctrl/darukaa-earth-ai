from pathlib import Path
import json

def main():
    k = Path("knowledge")
    idx = Path("index")
    idx.mkdir(exist_ok=True)
    docs = [{"id":p.stem,"path":str(p)} for p in sorted(k.glob("*.md"))]
    (idx/"catalog.json").write_text(json.dumps(docs, indent=2), encoding="utf-8")
    print(f"Indexed {len(docs)} knowledge documents.")

if __name__ == "__main__":
    main()
