from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class LocalRAG:
    def __init__(self, knowledge_dir):
        self.knowledge_dir = Path(knowledge_dir)
        self.documents = []
        self.vectorizer = None
        self.matrix = None
        self.load()

    def load(self):
        for path in sorted(self.knowledge_dir.glob("*.md")):
            self.documents.append({"id": path.stem, "title": path.stem.replace("_"," ").title(),
                                   "text": path.read_text(encoding="utf-8")})
        if self.documents:
            self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1,2))
            self.matrix = self.vectorizer.fit_transform([d["text"] for d in self.documents])

    def search(self, query, k=4):
        if not self.documents: return []
        q = self.vectorizer.transform([query])
        scores = cosine_similarity(q, self.matrix).ravel()
        return [{**self.documents[i], "score": float(scores[i])}
                for i in scores.argsort()[::-1][:k] if scores[i] > 0]
