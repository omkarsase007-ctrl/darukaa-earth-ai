sessions = {}

def add(session_id, role, text):
    sessions.setdefault(session_id, []).append({"role":role,"text":text})
    sessions[session_id] = sessions[session_id][-8:]

def context(session_id):
    return sessions.get(session_id, [])
