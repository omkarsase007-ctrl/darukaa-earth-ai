import re

def parse_environment(text: str) -> dict:
    t = text.lower()
    out = {}
    patterns = {
        "soc_percent": r"(?:soc|soil organic carbon)\s*(?:is|=|:)?\s*(\d+(?:\.\d+)?)\s*%",
        "rainfall_mm": r"(?:rainfall|rain)\s*(?:is|=|:)?\s*(\d+(?:\.\d+)?)\s*mm",
        "soil_moisture_percent": r"(?:soil moisture|moisture)\s*(?:is|=|:)?\s*(\d+(?:\.\d+)?)\s*%",
        "species_richness": r"(?:species richness|richness)\s*(?:is|=|:)?\s*(\d+(?:\.\d+)?)",
        "soil_ph": r"(?:soil pH|ph)\s*(?:is|=|:)\s*(\d+(?:\.\d+)?)",
    }
    for key, pattern in patterns.items():
        m = re.search(pattern, t)
        if m:
            out[key] = float(m.group(1))
    if "monoculture" in t: out["land_use"] = "monoculture"
    elif "intercrop" in t: out["land_use"] = "intercropping"
    for c in ["semi-arid","arid","humid"]:
        if c in t: out["climate"] = c
    for crop in ["wheat","rice","maize","cotton","soybean","sugarcane"]:
        if crop in t:
            out["crop"] = crop
            break
    if any(x in t for x in ["pollution","polluted","contamination"]): out["pollution"] = True
    if any(x in t for x in ["deforestation","forest loss","habitat loss"]): out["deforestation"] = True
    return out
