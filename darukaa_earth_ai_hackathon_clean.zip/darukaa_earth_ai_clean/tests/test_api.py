from fastapi.testclient import TestClient
from backend.main import app
client = TestClient(app)

def test_health():
    r=client.get("/health")
    assert r.status_code==200
    assert r.json()["status"]=="ok"

def test_recommend():
    r=client.post("/recommend",json={"text":"SOC 0.3%, rainfall 450 mm, soil moisture 12%, species richness 8, monoculture wheat, semi-arid"})
    assert r.status_code==200
    assert r.json()["recommendation"]
    assert r.json()["evidence"]
