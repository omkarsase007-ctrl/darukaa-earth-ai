import requests
import streamlit as st

st.set_page_config(page_title="Darukaa.Earth AI", page_icon="🌱")
st.title("🌱 Darukaa.Earth AI")
st.caption("Evidence-backed biodiversity and environmental reasoning")

api = st.sidebar.text_input("API URL", "http://localhost:8000")
session = st.sidebar.text_input("Session ID", "demo-session")
text = st.text_area("Describe the environmental situation",
    "SOC 0.3%, rainfall 450 mm/year, soil moisture 12%, species richness 8, monoculture wheat, semi-arid.",
    height=160)

if st.button("Generate recommendation", type="primary"):
    try:
        r = requests.post(api + "/chat", json={"session_id":session,"text":text}, timeout=30)
        r.raise_for_status()
        d = r.json()
        st.subheader("Recommendation"); st.write(d["recommendation"])
        st.subheader("Impacted metrics")
        st.write(", ".join(d["impacted_metrics"]))
        st.subheader("Time horizon"); st.write(d["time_horizon"])
        st.subheader("Confidence"); st.write(d["confidence"])
        st.subheader("Reasoning")
        for x in d["reasoning"]: st.write("• " + x)
        st.subheader("Extracted metrics"); st.json(d["extracted_metrics"])
        st.subheader("Evidence retrieved")
        for e in d["evidence"]: st.write(e)
    except Exception as e:
        st.error("Backend not reachable. Start FastAPI first.")
        st.code(str(e))
