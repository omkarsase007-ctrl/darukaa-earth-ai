# Agro-biodiversity
Crop diversification, rotations and intercropping can increase crop diversity and support ecosystem functions depending on local conditions.
Source: FAO State of the World's Biodiversity for Food and Agriculture (2019): https://www.fao.org/3/CA3129EN/CA3129EN.pdf
Agroforestry can add habitat structure and contribute to soil and water functions when species are locally appropriate.
Source: FAO Agroforestry: https://www.fao.org/agroforestry/en/
