# Human impact
Deforestation, habitat conversion and fragmentation can reduce habitat availability and connectivity.
Source: IPBES Global Assessment (2019): https://ipbes.net/global-assessment
Pollution can affect soil, freshwater and biodiversity. Identify pollutant, concentration and source before remediation.
