# Monitoring
Track soil organic carbon, soil moisture, pH, species richness, vegetation diversity, rainfall and crop diversity.
0-3 months: baseline and management indicators.
3-12 months: soil moisture and vegetation indicators.
1-3+ years: soil carbon and longer-term biodiversity trends.
Literature ranges must not be presented as site-specific predictions.
