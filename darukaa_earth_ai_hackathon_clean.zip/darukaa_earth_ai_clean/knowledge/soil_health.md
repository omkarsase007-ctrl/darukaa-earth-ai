# Soil health
Soil organic carbon (SOC) is an important soil-health indicator. Organic inputs, residue retention and ground cover can support soil carbon over time.
Source: FAO, Soil Organic Carbon: the hidden potential (2017): https://www.fao.org/3/i6937e/i6937e.pdf
Soil moisture is influenced by rainfall, soil texture and management. Mulch and residue can reduce evaporation.
Source: FAO Conservation Agriculture: https://www.fao.org/conservation-agriculture/en/
Soil pH affects nutrient availability and should be interpreted against crop and soil requirements.
