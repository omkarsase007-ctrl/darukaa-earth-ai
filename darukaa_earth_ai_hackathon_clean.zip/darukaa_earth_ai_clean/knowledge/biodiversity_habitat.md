# Biodiversity and habitat
Species richness is the number of observed species in a defined sampling unit and should be interpreted with sampling effort.
Habitat heterogeneity can provide a wider range of resources and niches. Native vegetation patches and field margins can contribute to habitat heterogeneity.
Source: IPBES Global Assessment (2019): https://ipbes.net/global-assessment
