# Climate and water
Rainfall amount and seasonality influence crop productivity, soil moisture and habitat suitability. Water-limited settings require locally adapted management.
Source: IPCC AR6 WGII (2022): https://www.ipcc.ch/report/ar6/wg2/
Water availability changes can affect species survival and habitat quality.
